﻿namespace DefaultNamespace {
    public enum Weapons {
        Pistol,
        Shotgun,
        Rifle,
        Sniper
    }
}